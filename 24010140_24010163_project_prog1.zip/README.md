# Chess
This is the final project for 2 CSE students for the subject programming 1
